public class Hospital{
    private int hospid;
    private String hospname;
    private int statecode;
    private String state;
    private int districtid;
    private String district;
    private int hospcontactno;
    private String hospaddress;
    private String hosptype;
}

    public void setHospid(int hospid){
        this.hospid = hospid;
    }

    public int getHospid(){
        return hospid;
    }

public void setHospname(String hospname){
    this.hospname = hospname;
}

public String getHospname(){
    return hospname;
}


    public void setHospname(int statecode){
        this.statecode = statecode;
    }

    public String getStatecode(){
        return statecode;
    }


    public void setState(String state){
        this.state = state;
    }

    public String getState(){
        return state;
    }


    public void setDistrictid(int districtid){
        this.districtid = districtid;
    }

    public String getDistrictid(){
        return districtid;
    }


    public void setDistrict(String district){
        this.district = district;
    }

    public String getDistrict(){
        return district;
    }


    public void setHospcontactno(int hospcontactno){
        this.hospcontactno = hospcontactno;
    }

    public String getHospcontactno(){
        return hospcontactno;
    }

    public void setHospaddress(String hospaddress){
        this.hospaddress = hospaddress;
    }

    public String getHospaddress(){
        return hospaddress;
    }


    public void setHosptype(String hosptype){
        this.hosptype = hosptype;
    }

    public String getHosptype(){
        return hosptype;
    }

    @Override
    public String toString(){
    return "{" +
            "hospname =' "+ hospname +
            ", statecode =" + statecode +
            ",state = " + state +
            ", istrictid = " + districtid +
            ", district = " +district +
            ", hospcontactno =" +hospcontactno+
            ", hospaddress =" +hospaddress+
            ", hosptype ="+hosptype+
            '}';

    }
