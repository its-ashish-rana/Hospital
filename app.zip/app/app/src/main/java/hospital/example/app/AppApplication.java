package hospital.example.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppApplication.class, args);
	}

	@Override
	public void run(String[] args) throws IOException {
		//object mapping
		ObjectMapper objectMapper = new ObjectMapper();

		//reading json data from file and converting to Hospital object

		Hospital hospital = ObjectMapper.readValue(new File(hospital.json), Hospital.class);

		// printing hospital data
		System.out.println(hospital);
	}
}