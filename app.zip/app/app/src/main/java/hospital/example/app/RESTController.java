    @RestController
    @RequestMapping(path = "/hospital")
    public class RESTController{

    @Autowired
        private Hospital hospital;

    @GetMapping(path = "/AllHospital", produces = "hospital/json")
        public Hospital getHospital(){
        return hospital.getAllHospital();
    }

        @GetMapping(path = "/HospitalbyCode", produces = "hospital/json")
        public Hospital getHospid(){
            return hospital.getHospid();
        }

        @GetMapping(path = "/Hospname", produces = "hospital/json")
        public Hospital getHospname(){
            return hospital.getHospname();
        }

        @GetMapping(path = "/State", produces = "hospital/json")
        public Hospital getHospital(){
            return hospital.getState();
        }

        @GetMapping(path = "/Hosptype", produces = "hospital/json")
        public Hospital getHospital(){
            return hospital.getHosptype();
        }


        @PostMapping(path = "/", consumes = "hospital/json", produces ="hospital/json")
        public ResponseEntity<Object> addHospital(@RequestBody Hospital hospital) {


        URI location = ServletUriComponentBuilder.fromCurrentRequest()
                .path("/{hospid}")
                .buildAndExpand(hospital.get)
                .toUri();

        return ResponseEntity.created(location).build();
    }
    }
