import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class HospitalUser {


}